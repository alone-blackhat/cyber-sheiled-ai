import React, { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  Bot, 
  Cpu,
  Bell,
  Wifi,
  Menu,
  X,
  ChevronLeft,
  ChevronRight
} from "lucide-react";
import { UserSkillLevel } from "./types";

// Page Components
import ChatAssistant from "./components/ChatAssistant";

type SidebarItem = 
  | "chat";

// Premium styling animations for Cyber Wolf Logo & Branding Section
const CYBER_STYLE_INJECTION = `
  @keyframes cyber-breath {
    0%, 100% {
      opacity: 0.65;
      transform: scale(0.97);
      filter: drop-shadow(0 0 6px rgba(0, 240, 255, 0.45));
    }
    50% {
      opacity: 1;
      transform: scale(1.03);
      filter: drop-shadow(0 0 18px rgba(0, 240, 255, 0.85)) drop-shadow(0 0 28px rgba(6, 182, 212, 0.5));
    }
  }
  @keyframes holo-pulse {
    0% {
      transform: scale(0.92);
      opacity: 0.18;
    }
    50% {
      opacity: 0.5;
    }
    100% {
      transform: scale(1.4);
      opacity: 0;
    }
  }
  @keyframes spin-slow {
    from {
      transform: rotate(0deg);
    }
    to {
      transform: rotate(360deg);
    }
  }
  @keyframes particle-float-1 {
    0% { transform: translate(0, 0) scale(0.8); opacity: 0; }
    50% { opacity: 0.8; }
    100% { transform: translate(-12px, -32px) scale(0.5); opacity: 0; }
  }
  @keyframes particle-float-2 {
    0% { transform: translate(0, 0) scale(0.8); opacity: 0; }
    50% { opacity: 0.8; }
    100% { transform: translate(12px, -28px) scale(0.5); opacity: 0; }
  }
  @keyframes particle-float-3 {
    0% { transform: translate(0, 0) scale(0.8); opacity: 0; }
    50% { opacity: 0.8; }
    100% { transform: translate(-6px, -38px) scale(0.5); opacity: 0; }
  }
  @keyframes text-glow-cyan {
    0%, 100% {
      text-shadow: 0 0 8px rgba(0, 240, 255, 0.6), 0 0 15px rgba(0, 240, 255, 0.25);
    }
    50% {
      text-shadow: 0 0 16px rgba(0, 240, 255, 0.95), 0 0 30px rgba(0, 240, 255, 0.55), 0 0 3px #fff;
    }
  }
`;

function CyberWolfBranding({ collapsed }: { collapsed: boolean }) {
  return (
    <div className="flex flex-col items-center justify-center text-center w-full select-none" id="cyber-wolf-branding-block">
      {/* Container for logo, energy ring, holographic pulse, and particles */}
      <div className="relative w-28 h-28 flex items-center justify-center mb-4">
        
        {/* Rotating Energy Ring behind logo */}
        <div 
          className="absolute inset-0 rounded-full border border-dashed border-[#00F0FF]/30"
          style={{
            animation: "spin-slow 15s linear infinite",
            boxShadow: "0 0 15px rgba(0, 240, 255, 0.05) inset, 0 0 15px rgba(0, 240, 255, 0.05)"
          }}
        />
        <div 
          className="absolute inset-2 rounded-full border border-double border-cyan-500/20"
          style={{
            animation: "spin-slow 25s linear infinite reverse"
          }}
        />

        {/* Holographic Pulse Effect circles */}
        <div 
          className="absolute w-24 h-24 rounded-full border border-cyan-400/40 pointer-events-none"
          style={{
            animation: "holo-pulse 4s cubic-bezier(0.16, 1, 0.3, 1) infinite"
          }}
        />
        <div 
          className="absolute w-24 h-24 rounded-full border border-blue-500/30 pointer-events-none"
          style={{
            animation: "holo-pulse 4s cubic-bezier(0.16, 1, 0.3, 1) infinite",
            animationDelay: "2s"
          }}
        />

        {/* Floating Particles around logo */}
        <div className="absolute top-4 left-6 w-1.5 h-1.5 rounded-full bg-cyan-400" style={{ animation: "particle-float-1 3.5s ease-in-out infinite" }} />
        <div className="absolute top-8 right-6 w-1 h-1 rounded-full bg-blue-400" style={{ animation: "particle-float-2 4s ease-in-out infinite", animationDelay: "1s" }} />
        <div className="absolute bottom-6 left-8 w-1 h-1 rounded-full bg-cyan-300" style={{ animation: "particle-float-3 4.5s ease-in-out infinite", animationDelay: "1.8s" }} />
        <div className="absolute bottom-8 right-8 w-1.5 h-1.5 rounded-full bg-[#00F0FF]" style={{ animation: "particle-float-1 3.8s ease-in-out infinite", animationDelay: "0.5s" }} />

        {/* Cyber Wolf Emblem (breathing animation) */}
        <div 
          className="relative z-10 w-24 h-24 flex items-center justify-center"
          style={{
            animation: "cyber-breath 4s ease-in-out infinite"
          }}
        >
          <svg viewBox="0 0 120 120" className="w-full h-full">
            <defs>
              <filter id="cyan-glow" x="-20%" y="-20%" width="140%" height="140%">
                <feGaussianBlur stdDeviation="5" result="blur" />
                <feComposite in="SourceGraphic" in2="blur" operator="over" />
              </filter>
            </defs>

            {/* Shield Frame Outer */}
            <path 
              d="M 60 10 L 105 26 L 105 74 Q 60 114 15 74 L 15 26 Z" 
              fill="none" 
              stroke="#00F0FF" 
              strokeWidth="2.5" 
              filter="url(#cyan-glow)"
              className="drop-shadow-[0_0_10px_#00F0FF]"
            />
            {/* Shield Frame Inner Grid Lines */}
            <path 
              d="M 60 15 L 98 29 L 98 70 Q 60 106 22 70 L 22 29 Z" 
              fill="#060913" 
              fillOpacity="0.85" 
              stroke="#005C8A" 
              strokeWidth="1.5" 
            />

            {/* Cyber Grid pattern inside shield */}
            <line x1="30" y1="35" x2="90" y2="35" stroke="#003554" strokeWidth="0.5" strokeDasharray="2 2" />
            <line x1="25" y1="55" x2="95" y2="55" stroke="#003554" strokeWidth="0.5" strokeDasharray="2 2" />
            <line x1="25" y1="75" x2="95" y2="75" stroke="#003554" strokeWidth="0.5" strokeDasharray="2 2" />
            <line x1="60" y1="15" x2="60" y2="105" stroke="#003554" strokeWidth="0.5" strokeDasharray="2 2" />

            {/* Cyber Wolf Head Geometry */}
            {/* Left and Right Ears */}
            <polygon points="42,38 22,14 46,28" fill="#040814" stroke="#00F0FF" strokeWidth="1.5" />
            <polygon points="78,38 98,14 74,28" fill="#040814" stroke="#00F0FF" strokeWidth="1.5" />
            {/* Inner Ear Highlights */}
            <polygon points="40,35 30,22 42,30" fill="#00D1FF" fillOpacity="0.4" />
            <polygon points="80,35 90,22 78,30" fill="#00D1FF" fillOpacity="0.4" />

            {/* Head Crest */}
            <polygon points="60,30 46,45 74,45" fill="#091322" stroke="#00F0FF" strokeWidth="1.2" />

            {/* Cheeks and Outer Plates */}
            <polygon points="46,45 28,58 44,66 60,52" fill="#030710" stroke="#00F0FF" strokeWidth="1.2" />
            <polygon points="74,45 92,58 76,66 60,52" fill="#030710" stroke="#00F0FF" strokeWidth="1.2" />

            {/* Cheeks Flairs */}
            <polygon points="28,58 18,66 32,70" fill="#040814" stroke="#00D1FF" strokeWidth="1" />
            <polygon points="92,58 102,66 88,70" fill="#040814" stroke="#00D1FF" strokeWidth="1" />

            {/* Center Forehead */}
            <polygon points="60,30 52,45 60,52 68,45" fill="#0c1d33" stroke="#00F0FF" strokeWidth="1" />

            {/* Snout and Bridge */}
            <polygon points="60,52 46,66 60,94 74,66" fill="#050E1A" stroke="#00F0FF" strokeWidth="1.5" />
            {/* Cyber Snout Tech lines */}
            <line x1="51" y1="72" x2="69" y2="72" stroke="#00D1FF" strokeWidth="1" />
            <line x1="55" y1="80" x2="65" y2="80" stroke="#00D1FF" strokeWidth="1" />

            {/* Glowing Cyber Nose */}
            <polygon points="56,86 60,94 64,86" fill="#00F0FF" className="drop-shadow-[0_0_6px_#00F0FF]" />

            {/* Piercing Glowing Eyes */}
            <polygon points="45,46 51,48 48,51" fill="#00F0FF" className="drop-shadow-[0_0_8px_#00F0FF]" />
            <polygon points="75,46 69,48 72,51" fill="#00F0FF" className="drop-shadow-[0_0_8px_#00F0FF]" />
            <circle cx="48" cy="48" r="1" fill="#FFFFFF" />
            <circle cx="72" cy="48" r="1" fill="#FFFFFF" />

            {/* Cyber Chin/Jaw Guard */}
            <polygon points="46,66 38,76 48,84 60,94" fill="#040814" stroke="#00D1FF" strokeWidth="1" />
            <polygon points="74,66 82,76 72,84 60,94" fill="#040814" stroke="#00D1FF" strokeWidth="1" />
          </svg>
        </div>
      </div>

      {/* Typography and info display */}
      {!collapsed && (
        <div className="flex flex-col items-center gap-1 px-3">
          <h2 
            className="text-[15px] font-black font-mono tracking-[0.25em] text-white uppercase"
            style={{
              animation: "text-glow-cyan 4s ease-in-out infinite"
            }}
          >
            BLACK_WOLF
          </h2>
          <div className="h-[2px] w-12 bg-gradient-to-r from-transparent via-[#00F0FF] to-transparent my-1" />
          <p className="text-[9px] font-mono font-bold tracking-wider text-[#00F0FF] uppercase">
            Enterprise AI Security Copilot
          </p>
          <div className="mt-4 flex flex-col items-center gap-0.5">
            <span className="text-[7.5px] font-mono font-bold tracking-[0.3em] text-gray-500 uppercase">
              Developed by
            </span>
            <span className="text-[12px] font-extrabold font-mono tracking-widest text-white uppercase bg-clip-text bg-gradient-to-r from-white via-cyan-300 to-white">
              P SOWNDHAR
            </span>
            <span className="text-[8.5px] font-mono font-bold tracking-[0.15em] text-cyan-400 uppercase">
              Professional Hacker
            </span>
          </div>
        </div>
      )}
    </div>
  );
}

export default function App() {
  const [activeTab, setActiveTab] = useState<SidebarItem>("chat");
  const [sidebarCollapsed, setSidebarCollapsed] = useState<boolean>(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState<boolean>(false);
  
  // Theme & Animation configuration states
  const [glowIntensity, setGlowIntensity] = useState<"low" | "medium" | "high">("medium");
  const [colorTheme, setColorTheme] = useState<"emerald" | "cyan" | "gold">("emerald");
  const [userLevel, setUserLevel] = useState<UserSkillLevel>("intermediate");
  const [currentTime, setCurrentTime] = useState<string>("");

  // Notification panel state
  const [notificationsOpen, setNotificationsOpen] = useState<boolean>(false);
  const [unreadCount, setUnreadCount] = useState<number>(3);
  const [notifications, setNotifications] = useState([
    { id: "1", text: "Critical: SSH brute force sweep blocked on gateway-v4", type: "high", time: "3 mins ago" },
    { id: "2", text: "Advisory: New Zero-Day session hijack exploit mapped", type: "medium", time: "1 hr ago" },
    { id: "3", text: "Integrity: Completed daily code security heuristics scan", type: "low", time: "4 hrs ago" }
  ]);

  const backgroundCanvasRef = useRef<HTMLCanvasElement>(null);

  // Time ticker
  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setCurrentTime(now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false }) + " UTC");
    };
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  // Theme Accent Variable Map
  const getThemeColor = (opacity: number = 1) => {
    if (colorTheme === "cyan") return `rgba(6, 182, 212, ${opacity})`;
    if (colorTheme === "gold") return `rgba(234, 179, 8, ${opacity})`;
    return `rgba(0, 255, 65, ${opacity})`; // Default Emerald
  };

  const getThemeHex = () => {
    if (colorTheme === "cyan") return "#06b6d4";
    if (colorTheme === "gold") return "#eab308";
    return "#00FF41";
  };

  // 60FPS Matrix Grid and Particles Background Canvas
  useEffect(() => {
    const canvas = backgroundCanvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let animFrameId: number;
    
    const handleResize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };
    handleResize();
    window.addEventListener("resize", handleResize);

    // Matrix digital streams
    const cols = Math.floor(canvas.width / 24) + 1;
    const ypos = Array(cols).fill(0);

    // Particle nodes
    const particles: any[] = [];
    for (let i = 0; i < 40; i++) {
      particles.push({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        vx: (Math.random() - 0.5) * 0.4,
        vy: (Math.random() - 0.5) * 0.4,
        size: Math.random() * 2 + 1,
        alpha: Math.random() * 0.4 + 0.1
      });
    }

    const draw = () => {
      // Clear with very dark slate back layer
      ctx.fillStyle = "rgba(5, 5, 5, 0.15)";
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      // 1. Digital Grid Overlay (Subtle)
      ctx.strokeStyle = "rgba(255, 255, 255, 0.012)";
      ctx.lineWidth = 0.5;
      const gridSize = 40;
      for (let x = 0; x < canvas.width; x += gridSize) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, canvas.height);
        ctx.stroke();
      }
      for (let y = 0; y < canvas.height; y += gridSize) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(canvas.width, y);
        ctx.stroke();
      }

      // 2. Matrix code streams (Drawn selectively for performance and clean UI aesthetic)
      ctx.font = "8px monospace";
      ypos.forEach((y, ind) => {
        if (Math.random() > 0.98) {
          const text = String.fromCharCode(48 + Math.floor(Math.random() * 2)); // Binary code 0/1
          const x = ind * 24;
          
          // Use current glow accent
          ctx.fillStyle = getThemeColor(0.08);
          ctx.fillText(text, x, y);
          
          if (y > canvas.height && Math.random() > 0.9) {
            ypos[ind] = 0;
          } else {
            ypos[ind] = y + 12;
          }
        }
      });

      // 3. Floating Neon Nodes
      particles.forEach((p) => {
        p.x += p.vx;
        p.y += p.vy;

        // Boundaries recycle
        if (p.x < 0) p.x = canvas.width;
        if (p.x > canvas.width) p.x = 0;
        if (p.y < 0) p.y = canvas.height;
        if (p.y > canvas.height) p.y = 0;

        ctx.fillStyle = getThemeColor(p.alpha);
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        ctx.fill();

        // Connect lines between nearby particles for constellation circuit grid
        particles.forEach((p2) => {
          const dx = p.x - p2.x;
          const dy = p.y - p2.y;
          const dist = Math.sqrt(dx * dx + dy * dy);
          if (dist < 100) {
            ctx.strokeStyle = getThemeColor((1 - dist / 100) * 0.02);
            ctx.lineWidth = 0.5;
            ctx.beginPath();
            ctx.moveTo(p.x, p.y);
            ctx.lineTo(p2.x, p2.y);
            ctx.stroke();
          }
        });
      });

      animFrameId = requestAnimationFrame(draw);
    };

    draw();

    return () => {
      cancelAnimationFrame(animFrameId);
      window.removeEventListener("resize", handleResize);
    };
  }, [colorTheme]);

  // Sidebar list items configurations
  const menuItems = [
    { id: "chat", label: "BLACK_WOLF AI Chat", icon: <Bot className="h-4 w-4" />, component: <ChatAssistant userLevel={userLevel} setUserLevel={setUserLevel} /> },
  ];

  const activeItem = menuItems.find((item) => item.id === activeTab) || menuItems[0];

  const handleClearNotifications = () => {
    setUnreadCount(0);
    setNotifications([]);
  };

  return (
    <div className="min-h-screen bg-[#050505] text-[#E0E0E0] font-sans flex flex-col selection:bg-cyan-500/20 selection:text-cyan-300 relative overflow-x-hidden">
      <style dangerouslySetInnerHTML={{ __html: CYBER_STYLE_INJECTION }} />
      
      {/* Background Animated Canvas Canvas Layer */}
      <canvas ref={backgroundCanvasRef} className="fixed inset-0 w-full h-full pointer-events-none z-0" />

      {/* Top Navbar Header */}
      <header className="h-16 border-b border-[#1A1A1A] bg-[#0A0A0A]/95 flex items-center justify-between px-6 sticky top-0 z-40 backdrop-blur-md shrink-0 select-none">
        <div className="flex items-center space-x-4">
          {/* Mobile menu trigger */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="p-1.5 bg-[#111] hover:bg-[#1A1A1A] border border-[#222] rounded-lg text-white md:hidden cursor-pointer"
          >
            {mobileMenuOpen ? <X className="h-4 w-4" /> : <Menu className="h-4 w-4" />}
          </button>

          {/* Animated 3D BLACK_WOLF Logo with Neon Outline & Blue Eyes */}
          <div className="flex items-center space-x-3.5 group">
            <div className="w-10 h-10 bg-[#0E0E0E]/90 border border-gray-800 rounded-xl flex items-center justify-center relative overflow-hidden shadow-lg shadow-black/80">
              {/* Pulsing breathing outline glow */}
              <div 
                className="absolute inset-0 border-2 rounded-xl opacity-40"
                style={{ borderColor: "#00F0FF", animation: "cyber-breath 4s ease-in-out infinite" }}
              />
              {/* Premium Original Cyber Wolf Logo (Mini) */}
              <svg viewBox="0 0 120 120" className="w-8 h-8 relative z-10">
                {/* Shield Frame Outer */}
                <path d="M 60 10 L 105 26 L 105 74 Q 60 114 15 74 L 15 26 Z" fill="none" stroke="#00F0FF" strokeWidth="2.5" className="drop-shadow-[0_0_4px_#00F0FF]" />
                {/* Shield Frame Inner */}
                <path d="M 60 15 L 98 29 L 98 70 Q 60 106 22 70 L 22 29 Z" fill="#060913" stroke="#005C8A" strokeWidth="1.5" />
                {/* Ears */}
                <polygon points="42,38 22,14 46,28" fill="#040814" stroke="#00F0FF" strokeWidth="1.5" />
                <polygon points="78,38 98,14 74,28" fill="#040814" stroke="#00F0FF" strokeWidth="1.5" />
                {/* Head Crest */}
                <polygon points="60,30 46,45 74,45" fill="#091322" stroke="#00F0FF" strokeWidth="1.2" />
                {/* Cheeks */}
                <polygon points="46,45 28,58 44,66 60,52" fill="#030710" stroke="#00F0FF" strokeWidth="1.2" />
                <polygon points="74,45 92,58 76,66 60,52" fill="#030710" stroke="#00F0FF" strokeWidth="1.2" />
                {/* Snout */}
                <polygon points="60,52 46,66 60,94 74,66" fill="#050E1A" stroke="#00F0FF" strokeWidth="1.5" />
                {/* Nose */}
                <polygon points="56,86 60,94 64,86" fill="#00F0FF" />
                {/* Eyes */}
                <polygon points="45,46 51,48 48,51" fill="#00F0FF" className="drop-shadow-[0_0_4px_#00F0FF]" />
                <polygon points="75,46 69,48 72,51" fill="#00F0FF" className="drop-shadow-[0_0_4px_#00F0FF]" />
              </svg>
            </div>

            <div>
              <h1 className="text-sm sm:text-base font-black font-mono tracking-wider text-white flex items-center gap-1.5 uppercase">
                BLACK_WOLF <span style={{ color: "#00F0FF", textShadow: "0 0 8px rgba(0,240,255,0.6)" }}>AI</span>
              </h1>
              <p className="text-[8px] uppercase tracking-widest text-gray-500 font-bold font-mono">SecOps Control Platform</p>
            </div>
          </div>
        </div>

        {/* Global Navbar Tools HUD */}
        <div className="flex items-center space-x-4">
          
          {/* Connection Status Indicator */}
          <div className="hidden lg:flex items-center space-x-2 bg-[#050505] border border-[#1C1C1C] px-3 py-1.5 rounded-lg text-[10px] font-mono">
            <Wifi className="h-3.5 w-3.5" style={{ color: getThemeHex() }} />
            <span className="text-gray-400 font-bold">SECURE_LINK:</span>
            <span style={{ color: getThemeHex() }} className="font-bold">ESTABLISHED</span>
          </div>

          {/* Core Model Indicator */}
          <div className="hidden sm:flex items-center space-x-2 bg-[#050505] border border-[#1C1C1C] px-3 py-1.5 rounded-lg text-[10px] font-mono">
            <Cpu className="h-3.5 w-3.5 text-cyan-400" />
            <span className="text-gray-400">ENGINE:</span>
            <span className="text-cyan-400 font-bold uppercase">{userLevel}</span>
          </div>

          {/* Current Live UTC Time */}
          <div className="hidden sm:block bg-[#050505] border border-[#1C1C1C] px-3.5 py-1.5 rounded-lg text-[10px] font-mono text-gray-400 select-none">
            {currentTime || "00:00:00 UTC"}
          </div>

          {/* Notification Hub trigger */}
          <div className="relative">
            <button
              onClick={() => setNotificationsOpen(!notificationsOpen)}
              className="p-2 bg-[#050505] hover:bg-[#111] border border-[#222] rounded-lg text-gray-400 hover:text-white transition-all cursor-pointer relative"
            >
              <Bell className="h-4 w-4" />
              {unreadCount > 0 && (
                <span className="absolute -top-1 -right-1 w-4 h-4 bg-red-500 text-black font-mono text-[8px] font-black rounded-full flex items-center justify-center animate-bounce">
                  {unreadCount}
                </span>
              )}
            </button>

            {/* Notification Dropdown List */}
            <AnimatePresence>
              {notificationsOpen && (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: 10 }}
                  className="absolute right-0 mt-2 w-72 bg-[#0A0A0A] border border-[#1C1C1C] rounded-xl shadow-2xl p-4 z-50 flex flex-col gap-3 font-mono text-[11px]"
                >
                  <div className="flex justify-between items-center border-b border-[#222] pb-2">
                    <span className="font-bold text-white uppercase tracking-wider">SECURE_ALERTS</span>
                    {unreadCount > 0 && (
                      <button
                        onClick={handleClearNotifications}
                        className="text-[9px] text-gray-500 hover:text-red-400 cursor-pointer"
                      >
                        CLEAR ALL
                      </button>
                    )}
                  </div>

                  <div className="space-y-2 max-h-52 overflow-y-auto pr-1 custom-scrollbar">
                    {notifications.map((notif) => (
                      <div key={notif.id} className="p-2 bg-[#050505] border border-[#1C1C1C] rounded-lg">
                        <div className="flex justify-between items-center text-[9px] mb-1">
                          <span className={`font-bold uppercase ${notif.type === "high" ? "text-red-400" : "text-yellow-400"}`}>
                            {notif.type}
                          </span>
                          <span className="text-gray-600">{notif.time}</span>
                        </div>
                        <p className="text-gray-300 leading-normal text-[10px]">{notif.text}</p>
                      </div>
                    ))}

                    {notifications.length === 0 && (
                      <p className="text-center text-gray-600 py-6">No unread alerts.</p>
                    )}
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* Theme switcher shortcut */}
          <button
            onClick={() => setColorTheme(colorTheme === "emerald" ? "cyan" : colorTheme === "cyan" ? "gold" : "emerald")}
            className="p-2 bg-[#050505] hover:bg-[#111] border border-[#222] rounded-lg text-gray-400 hover:text-white transition-all cursor-pointer text-xs"
            title="Switch Theme Color Accent"
          >
            🎨
          </button>
        </div>
      </header>

      {/* Main Container Layout */}
      <div className="flex-1 flex relative z-10 overflow-hidden select-none">
        
        {/* Desktop Sidebar (Collapsible) */}
        <aside 
          className="hidden md:flex flex-col bg-[#080808]/95 border-r border-[#1A1A1A] py-5 transition-all duration-300 shrink-0 select-none z-30"
          style={{ width: sidebarCollapsed ? "72px" : "240px" }}
        >
          {/* Collapse toggle */}
          <div className="px-4 mb-4 flex justify-end">
            <button
              onClick={() => setSidebarCollapsed(!sidebarCollapsed)}
              className="p-1.5 bg-[#050505] hover:bg-[#111] border border-[#1C1C1C] rounded-lg text-gray-500 hover:text-white cursor-pointer"
            >
              {sidebarCollapsed ? <ChevronRight className="h-3.5 w-3.5" /> : <ChevronLeft className="h-3.5 w-3.5" />}
            </button>
          </div>

          {/* Premium Animated BLACK_WOLF Branding */}
          <div className="mb-6 transition-all duration-300">
            <CyberWolfBranding collapsed={sidebarCollapsed} />
          </div>

          {/* Navigation Links List */}
          <nav className="flex-1 space-y-1.5 px-3 overflow-y-auto scrollbar-thin">
            {menuItems.map((item) => {
              const active = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => {
                    setActiveTab(item.id as SidebarItem);
                    setMobileMenuOpen(false);
                  }}
                  className={`w-full flex items-center gap-3 py-2.5 px-3.5 rounded-xl transition-all duration-200 cursor-pointer group text-xs font-mono font-medium relative ${
                    active
                      ? "text-black font-bold"
                      : "text-gray-400 hover:text-white hover:bg-[#111]/40"
                  }`}
                  style={{
                    backgroundColor: active ? getThemeColor() : "transparent",
                    boxShadow: active ? `0 0 12px ${getThemeColor(0.25)}` : "none"
                  }}
                >
                  <div className={`transition-transform group-hover:scale-105 ${active ? "text-black" : "text-gray-500 group-hover:text-white"}`}>
                    {item.icon}
                  </div>
                  {!sidebarCollapsed && <span className="truncate">{item.label}</span>}
                </button>
              );
            })}
          </nav>
        </aside>

        {/* Mobile Navigation Drawer Dropdown */}
        <AnimatePresence>
          {mobileMenuOpen && (
            <motion.div
              initial={{ x: "-100%" }}
              animate={{ x: 0 }}
              exit={{ x: "-100%" }}
              transition={{ type: "tween", duration: 0.2 }}
              className="fixed inset-y-16 left-0 w-64 bg-[#0A0A0A] border-r border-[#1C1C1C] z-50 flex flex-col p-4 md:hidden shadow-2xl"
            >
              <nav className="space-y-1 overflow-y-auto">
                {menuItems.map((item) => {
                  const active = activeTab === item.id;
                  return (
                    <button
                      key={item.id}
                      onClick={() => {
                        setActiveTab(item.id as SidebarItem);
                        setMobileMenuOpen(false);
                      }}
                      className="w-full flex items-center gap-3 py-3 px-4 rounded-xl text-xs font-mono text-left transition-all"
                      style={{
                        backgroundColor: active ? getThemeColor() : "transparent",
                        color: active ? "#000" : "#AAA",
                        fontWeight: active ? "bold" : "normal"
                      }}
                    >
                      {item.icon}
                      <span>{item.label}</span>
                    </button>
                  );
                })}
              </nav>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Unified Workstage Display Container */}
        <main className="flex-1 p-4 sm:p-6 lg:p-8 overflow-y-auto z-10 select-text">
          <div className="max-w-7xl mx-auto">
            <AnimatePresence mode="wait">
              <motion.div
                key={activeTab}
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -15 }}
                transition={{ duration: 0.2 }}
              >
                {activeItem.component}
              </motion.div>
            </AnimatePresence>
          </div>
        </main>

      </div>

      {/* Footer Info HUD */}
      <footer className="h-10 bg-[#080808] border-t border-[#1A1A1A] px-6 flex items-center justify-between text-[9px] font-mono text-gray-500 shrink-0 relative z-10 select-none">
        <div className="flex space-x-6">
          <span className="hidden sm:inline">CIPHER_ALGO: AES-256-GCM-TUNNEL</span>
          <span className="hidden md:inline">VERSION: v1.2.0-STRICT</span>
          <span>SYSTEM_STATE: <span className="text-[#00FF41]">OPERATIONAL</span></span>
        </div>
        <div className="flex items-center space-x-4">
          <span className="text-gray-600 hidden md:inline">USER: sowndharp24@gmail.com</span>
          <span className="bg-[#111] px-2 py-0.5 border border-[#222] rounded text-[8px]">r4_TLS_1.3</span>
        </div>
      </footer>

    </div>
  );
}
