export type UserSkillLevel = "beginner" | "intermediate" | "advanced";

export interface Message {
  id: string;
  role: "user" | "model";
  text: string;
  timestamp: string;
}

export interface CoreRule {
  id: number;
  title: string;
  description: string;
  extendedExplanation: string;
  beginnerApproach: string;
  intermediateApproach: string;
  advancedApproach: string;
  category: "quality" | "security" | "communication" | "ethics";
}

export interface PasswordAnalysis {
  entropy: number;
  strength: "weak" | "medium" | "strong" | "excellent";
  suggestions: string[];
  bruteForceOnline: number;
  bruteForceOffline: number;
}

export interface HeaderCheckResult {
  name: string;
  header: string;
  present: boolean;
  severity: "low" | "medium" | "high";
  impact: string;
  value: string | null;
}

export interface HeadersScanResult {
  score: number;
  results: HeaderCheckResult[];
}

export interface VulnScenario {
  id: string;
  title: string;
  description: string;
  vulnerableCode: string;
  secureCode: string;
  language: string;
  exploitPayload: string;
  exploitResult: string;
  secureResult: string;
  impactExplanation: string;
}
