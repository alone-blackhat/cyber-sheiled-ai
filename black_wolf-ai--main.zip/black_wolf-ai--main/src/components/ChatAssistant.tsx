import React, { useState, useRef, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  Send, 
  Sparkles, 
  Bot, 
  User, 
  ArrowRight, 
  Terminal, 
  AlertTriangle,
  RotateCcw,
  RefreshCw,
  Copy,
  Cpu,
  Shield,
  Zap,
  Lock,
  Globe,
  Database
} from "lucide-react";
import Markdown from "react-markdown";
import { Message, UserSkillLevel } from "../types";

interface ChatAssistantProps {
  userLevel: UserSkillLevel;
  setUserLevel: (level: UserSkillLevel) => void;
}

const STARTER_PROMPTS: Record<UserSkillLevel, { label: string; text: string }[]> = {
  beginner: [
    { label: "Password Strength", text: "How do hackers crack passwords step-by-step, and what makes a password truly secure?" },
    { label: "Explain SQL Injection", text: "Explain SQL Injection in simple terms with an everyday analogy." },
    { label: "Phishing Prevention", text: "What is phishing and social engineering, and what are the key red flags to look for?" },
  ],
  intermediate: [
    { label: "Secure Express Backend", text: "Show me how to secure an Express JS backend using helmet headers and write a brief guide." },
    { label: "Bcrypt Hashing", text: "Write a safe function to hash and verify passwords in Node.js using bcrypt with comments." },
    { label: "CORS Protection", text: "How does Cross-Origin Resource Sharing (CORS) work and what are secure configurations for Express?" },
  ],
  advanced: [
    { label: "JWT Review Checklist", text: "Draft a secure code review checklist for JWT-based authentication in modern web apps." },
    { label: "Prototype Pollution", text: "What are the security implications of Prototype Pollution in JavaScript and how do we prevent it?" },
    { label: "Secure Parameterization", text: "Explain how a SQL Injection exploit works at the database query execution level and write a secure parameterized query in Postgres." },
  ],
};

// --- Futuristic Cyber CSS Keyframes and Styling Rules ---
const PREMIUM_CYBER_STYLE_INJECTION = `
  @keyframes cyber-breathing {
    0%, 100% {
      transform: scale(0.97);
      filter: drop-shadow(0 0 15px rgba(0, 229, 255, 0.4)) drop-shadow(0 0 30px rgba(0, 229, 255, 0.15));
    }
    50% {
      transform: scale(1.03);
      filter: drop-shadow(0 0 35px rgba(0, 229, 255, 0.8)) drop-shadow(0 0 50px rgba(0, 255, 153, 0.4));
    }
  }

  @keyframes ring-rotate-clockwise {
    from { transform: rotate(0deg); }
    to { transform: rotate(360deg); }
  }

  @keyframes ring-rotate-counter {
    from { transform: rotate(360deg); }
    to { transform: rotate(0deg); }
  }

  @keyframes float-particle {
    0% {
      transform: translateY(10px) translateX(0) scale(0.8);
      opacity: 0;
    }
    50% {
      opacity: 0.8;
    }
    100% {
      transform: translateY(-80px) translateX(var(--drift-x, 15px)) scale(1.2);
      opacity: 0;
    }
  }

  @keyframes premium-pulse-hologram {
    0% {
      transform: scale(0.9);
      opacity: 0.1;
    }
    50% {
      opacity: 0.4;
    }
    100% {
      transform: scale(1.4);
      opacity: 0;
    }
  }

  @keyframes title-shimmer {
    0%, 100% {
      text-shadow: 0 0 12px rgba(0, 229, 255, 0.6), 0 0 25px rgba(0, 229, 255, 0.2);
    }
    50% {
      text-shadow: 0 0 24px rgba(0, 229, 255, 0.95), 0 0 45px rgba(0, 255, 153, 0.5), 0 0 4px #ffffff;
    }
  }

  @keyframes state-active-pulse {
    0%, 100% { opacity: 0.65; }
    50% { opacity: 1; }
  }

  /* Core Premium Classes */
  .glass-cyber-panel {
    background: rgba(7, 11, 18, 0.65);
    backdrop-filter: blur(25px);
    border: 1px solid rgba(0, 229, 255, 0.15);
    box-shadow: 0 25px 65px rgba(0, 0, 0, 0.85);
  }

  .glass-card-user-premium {
    background: rgba(0, 255, 153, 0.02);
    backdrop-filter: blur(15px);
    border: 1px solid rgba(0, 255, 153, 0.18);
    box-shadow: 0 8px 32px 0 rgba(0, 255, 153, 0.04);
  }

  .glass-card-assistant-premium {
    background: rgba(5, 9, 16, 0.85);
    backdrop-filter: blur(15px);
    border: 1px solid rgba(0, 229, 255, 0.1);
    box-shadow: 0 8px 32px 0 rgba(0, 0, 0, 0.6);
  }

  .glass-input-box {
    background: rgba(4, 7, 12, 0.85);
    backdrop-filter: blur(12px);
    border: 1px solid rgba(0, 229, 255, 0.16);
    transition: all 0.3s cubic-bezier(0.16, 1, 0.3, 1);
  }

  .glass-input-box:focus {
    border-color: #00E5FF;
    box-shadow: 0 0 20px rgba(0, 229, 255, 0.3);
  }

  /* Custom Scrollbar for Terminal Chat */
  .cyber-scroller::-webkit-scrollbar {
    width: 6px;
    height: 6px;
  }
  .cyber-scroller::-webkit-scrollbar-track {
    background: rgba(0, 0, 0, 0.3);
  }
  .cyber-scroller::-webkit-scrollbar-thumb {
    background: rgba(0, 229, 255, 0.18);
    border-radius: 99px;
  }
  .cyber-scroller::-webkit-scrollbar-thumb:hover {
    background: rgba(0, 229, 255, 0.45);
  }
`;

// --- Custom Markdown Subcomponents for Premium Presentation ---

function CodeBlock({ children, className, ...props }: any) {
  const match = /language-(\w+)/.exec(className || "");
  const codeString = String(children).replace(/\n$/, "");
  const [copied, setCopied] = useState(false);
  
  const handleCopy = () => {
    navigator.clipboard.writeText(codeString);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return match ? (
    <div className="relative my-5 rounded-xl overflow-hidden border border-cyan-500/20 bg-[#040811]/95 font-mono text-xs shadow-2xl">
      <div className="flex items-center justify-between px-4 py-2.5 bg-[#070D1A] border-b border-cyan-500/15 text-gray-400 select-none">
        <div className="flex items-center gap-2">
          {/* Mock Mac OS styled dots */}
          <div className="flex gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-red-500/70" />
            <span className="w-2.5 h-2.5 rounded-full bg-yellow-500/70" />
            <span className="w-2.5 h-2.5 rounded-full bg-green-500/70" />
          </div>
          <span className="text-[10px] font-mono tracking-wider uppercase text-[#00FF99] ml-2.5 font-bold">
            {match[1]}
          </span>
        </div>
        <button
          onClick={handleCopy}
          className="flex items-center gap-1.5 text-[10px] hover:text-[#00E5FF] transition-colors cursor-pointer font-semibold text-gray-500 hover:text-white"
        >
          <Copy className="h-3.5 w-3.5" />
          <span>{copied ? "COPIED" : "COPY CODE"}</span>
        </button>
      </div>
      <pre className="p-4 overflow-x-auto text-[#00E5FF] max-w-full font-mono leading-relaxed bg-[#02050B]/50 cyber-scroller">
        <code className={className} {...props}>
          {children}
        </code>
      </pre>
    </div>
  ) : (
    <code className="px-1.5 py-0.5 bg-[#091524] text-[#00FF99] rounded font-mono text-xs border border-cyan-500/20" {...props}>
      {children}
    </code>
  );
}

function TableComponent({ children }: any) {
  return (
    <div className="overflow-x-auto my-5 rounded-xl border border-cyan-500/15 cyber-scroller">
      <table className="min-w-full divide-y divide-cyan-500/15 text-xs text-gray-300 font-sans">
        {children}
      </table>
    </div>
  );
}

function TableHeaderComponent({ children }: any) {
  return <thead className="bg-[#091526] font-mono text-[10px] text-[#00FF99] tracking-wider text-left uppercase">{children}</thead>;
}

function TableBodyComponent({ children }: any) {
  return <tbody className="divide-y divide-cyan-500/15 bg-slate-950/40">{children}</tbody>;
}

function TableRowComponent({ children }: any) {
  return <tr className="hover:bg-cyan-500/5 transition-colors">{children}</tr>;
}

function TableCellComponent({ children }: any) {
  return <td className="px-4 py-3.5 text-left align-middle font-mono text-xs">{children}</td>;
}

function Heading1Component({ children }: any) {
  return <h1 className="text-sm font-mono font-bold text-white uppercase tracking-wider mt-6 mb-3 border-b border-cyan-500/15 pb-2 flex items-center gap-2"><span className="w-1.5 h-3.5 bg-[#00E5FF] inline-block rounded" />{children}</h1>;
}

function Heading2Component({ children }: any) {
  return <h2 className="text-xs font-mono font-semibold text-[#00FF99] uppercase tracking-wider mt-5 mb-3 flex items-center gap-1.5"><span className="w-1 h-2.5 bg-[#00FF99] inline-block rounded" />{children}</h2>;
}

function Heading3Component({ children }: any) {
  return <h3 className="text-[11px] font-mono font-semibold text-[#00E5FF] uppercase tracking-wide mt-4 mb-2.5">{children}</h3>;
}

function BulletListComponent({ children }: any) {
  return <ul className="list-disc pl-5 my-3.5 space-y-2 text-gray-300 font-sans text-xs">{children}</ul>;
}

function NumberedListComponent({ children }: any) {
  return <ol className="list-decimal pl-5 my-3.5 space-y-2 text-gray-300 font-sans text-xs">{children}</ol>;
}

function LinkComponent({ href, children }: any) {
  return (
    <a href={href} target="_blank" rel="noopener noreferrer" className="text-[#00FF99] hover:underline underline-offset-2 hover:text-[#00E5FF] transition-colors font-medium">
      {children}
    </a>
  );
}

// --- End Custom Markdown Subcomponents ---

export default function ChatAssistant({ userLevel, setUserLevel }: ChatAssistantProps) {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "welcome",
      role: "model",
      text: "Greetings. I am **BLACK_WOLF AI**.\n\nI am configured as an advanced, deep-learning security intelligence copilot. My matrix is loaded with enterprise security modules, secure application engineering standards, and defensive logic structures.\n\n*Threat modeling, secure parameterization checks, sandbox evaluation, and diagnostic scripting layers are fully initialized.* How may I protect and elevate your code infrastructure today?",
      timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
    },
  ]);
  const [inputText, setInputText] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [isConfigError, setIsConfigError] = useState(false);
  const [retryCount, setRetryCount] = useState<number>(0);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const abortControllerRef = useRef<AbortController | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isLoading]);

  // High Performance Canvas Background Effect: Scrolling Cyber Grid, Drifting Floating Particles, Soft Radial Glows, Falling Binary Matrix Rain
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let animationFrameId: number;
    let width = canvas.width = canvas.offsetWidth;
    let height = canvas.height = canvas.offsetHeight;

    const handleResize = () => {
      if (!canvas) return;
      width = canvas.width = canvas.offsetWidth;
      height = canvas.height = canvas.offsetHeight;
    };
    window.addEventListener("resize", handleResize);

    // Particles array
    const particles: { x: number; y: number; size: number; speed: number; alpha: number; color: string; drift: number }[] = [];
    for (let i = 0; i < 55; i++) {
      particles.push({
        x: Math.random() * width,
        y: Math.random() * height,
        size: Math.random() * 2 + 0.6,
        speed: Math.random() * 0.3 + 0.1,
        alpha: Math.random() * 0.3 + 0.1,
        color: Math.random() > 0.4 ? "#00E5FF" : "#00FF99",
        drift: Math.random() * 0.4 - 0.2
      });
    }

    // Binary columns
    const fontSize = 10;
    const columns = Math.floor(width / 32);
    const drops: number[] = Array(columns).fill(0).map(() => Math.random() * -height);

    let gridOffset = 0;

    const render = () => {
      ctx.fillStyle = "#070B12"; // Theme color background
      ctx.fillRect(0, 0, width, height);

      const time = Date.now() * 0.0006;
      const glow1X = width * 0.3 + Math.sin(time * 0.3) * 80;
      const glow1Y = height * 0.4 + Math.cos(time * 0.3) * 80;
      const glow2X = width * 0.7 + Math.cos(time * 0.2) * 80;
      const glow2Y = height * 0.6 + Math.sin(time * 0.2) * 80;

      // Soft Blue Radial Glow
      let g1 = ctx.createRadialGradient(glow1X, glow1Y, 0, glow1X, glow1Y, Math.max(width, height) * 0.5);
      g1.addColorStop(0, "rgba(0, 229, 255, 0.08)");
      g1.addColorStop(1, "rgba(0, 0, 0, 0)");
      ctx.fillStyle = g1;
      ctx.fillRect(0, 0, width, height);

      // Soft Emerald Radial Glow
      let g2 = ctx.createRadialGradient(glow2X, glow2Y, 0, glow2X, glow2Y, Math.max(width, height) * 0.45);
      g2.addColorStop(0, "rgba(0, 255, 153, 0.05)");
      g2.addColorStop(1, "rgba(0, 0, 0, 0)");
      ctx.fillStyle = g2;
      ctx.fillRect(0, 0, width, height);

      // Cyber grid lines
      gridOffset = (gridOffset + 0.2) % 40;
      ctx.strokeStyle = "rgba(0, 229, 255, 0.022)";
      ctx.lineWidth = 1;

      for (let x = 0; x < width; x += 40) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, height);
        ctx.stroke();
      }
      for (let y = gridOffset; y < height; y += 40) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(width, y);
        ctx.stroke();
      }

      // Matrix Rain
      ctx.fillStyle = "rgba(0, 255, 153, 0.08)";
      ctx.font = `${fontSize}px monospace`;
      for (let i = 0; i < drops.length; i++) {
        const text = Math.random() > 0.5 ? "1" : "0";
        const x = i * 32 + 16;
        const y = drops[i];

        ctx.fillText(text, x, y);

        if (y > height && Math.random() > 0.985) {
          drops[i] = 0;
        }
        drops[i] += 1.0;
      }

      // Floating particles
      for (let p of particles) {
        ctx.fillStyle = p.color;
        ctx.globalAlpha = p.alpha;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        ctx.fill();

        p.y -= p.speed;
        p.x += p.drift;
        if (p.y < 0) {
          p.y = height;
          p.x = Math.random() * width;
        }
        if (p.x < 0 || p.x > width) {
          p.x = Math.random() * width;
        }
      }
      ctx.globalAlpha = 1.0;

      animationFrameId = requestAnimationFrame(render);
    };

    render();

    return () => {
      window.removeEventListener("resize", handleResize);
      cancelAnimationFrame(animationFrameId);
    };
  }, []);

  const executeChatRequest = async (conversationHistory: { role: string; text: string }[]) => {
    setErrorMsg(null);
    setIsLoading(true);

    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
      abortControllerRef.current = null;
    }

    const controller = new AbortController();
    abortControllerRef.current = controller;

    let attempts = 0;
    const maxRetries = 5;
    let success = false;
    let finalBotResponseText = "";

    setRetryCount(0);

    while (attempts < maxRetries && !success) {
      if (controller.signal.aborted) {
        return;
      }

      attempts++;
      if (attempts > 1) {
        setRetryCount(attempts);
        const delay = Math.pow(2, attempts - 2) * 1000 + Math.random() * 200;
        
        try {
          await new Promise<void>((resolve, reject) => {
            const timer = setTimeout(resolve, delay);
            controller.signal.addEventListener("abort", () => {
              clearTimeout(timer);
              reject(new DOMException("Aborted", "AbortError"));
            });
          });
        } catch (abortErr) {
          return;
        }
      }

      if (controller.signal.aborted) {
        return;
      }

      let timeoutId: any;
      try {
        const fetchPromise = fetch("/api/chat", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            messages: conversationHistory,
            userLevel,
          }),
          signal: controller.signal,
        });

        const timeoutPromise = new Promise<never>((_, reject) => {
          timeoutId = setTimeout(() => {
            reject(new Error("TimeoutError"));
          }, 25000);
        });

        const res = await Promise.race([fetchPromise, timeoutPromise]);
        clearTimeout(timeoutId);

        if (controller.signal.aborted) {
          return;
        }

        if (!res) {
          throw new Error("InvalidResponse");
        }

        const data = await res.json().catch(() => {
          throw new Error("InvalidJSON");
        });

        if (controller.signal.aborted) {
          return;
        }

        if (!res.ok) {
          if (res.status === 429 || res.status === 503) {
            throw new Error(`StatusError_${res.status}`);
          } else {
            const rawMsg = data?.error || "Server responded with an error.";
            const customErr: any = new Error(rawMsg);
            customErr.isConfigError = !!(data?.isConfigError || rawMsg.includes("GEMINI_API_KEY") || rawMsg.includes("Settings > Secrets"));
            throw customErr;
          }
        }

        if (!data || typeof data.text !== "string") {
          throw new Error("InvalidResponseStructure");
        }

        finalBotResponseText = data.text;
        success = true;

      } catch (err: any) {
        clearTimeout(timeoutId);

        if (controller.signal.aborted || err.name === "AbortError" || err.message === "Aborted") {
          console.log("BLACK_WOLF AI request aborted.");
          return;
        }

        console.error(`BLACK_WOLF AI Core Request Attempt ${attempts} failed:`, err);

        const isRetryable = 
          err.message === "TimeoutError" || 
          err.message === "InvalidResponse" ||
          err.message === "InvalidJSON" ||
          err.message === "InvalidResponseStructure" ||
          err.message?.includes("StatusError_429") || 
          err.message?.includes("StatusError_503") ||
          err.message?.includes("fetch") || 
          err.message?.includes("Failed to fetch") || 
          err.message?.includes("NetworkError");

        if (isRetryable && attempts < maxRetries) {
          continue;
        } else {
          if (err.isConfigError) {
            setErrorMsg("Authentication config error detected. Please verify your GEMINI_API_KEY in Settings > Secrets.");
            setIsConfigError(true);
          } else if (attempts >= maxRetries) {
            setErrorMsg("The AI service is temporarily unavailable. Please try again in a few moments.");
          } else {
            setErrorMsg("An unexpected connection issue occurred. Please check your network and try again.");
          }
          break;
        }
      }
    }

    if (success && finalBotResponseText) {
      const botMsg: Message = {
        id: crypto.randomUUID(),
        role: "model",
        text: finalBotResponseText,
        timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
      };
      setMessages((prev) => [...prev, botMsg]);
    }

    setIsLoading(false);
    setRetryCount(0);
    if (abortControllerRef.current === controller) {
      abortControllerRef.current = null;
    }
  };

  const handleSendMessage = async (textToSend: string) => {
    const trimmed = textToSend.trim();
    if (!trimmed) return;

    setInputText("");

    const userMsg: Message = {
      id: crypto.randomUUID(),
      role: "user",
      text: trimmed,
      timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
    };

    const nextMessages = [...messages, userMsg];
    setMessages(nextMessages);

    const conversationHistory = nextMessages.map((msg) => ({
      role: msg.role,
      text: msg.text,
    }));

    await executeChatRequest(conversationHistory);
  };

  const handleNewChat = () => {
    setMessages([
      {
        id: "welcome-new",
        role: "model",
        text: "Greetings. I am **BLACK_WOLF AI**.\n\nI am configured as an advanced, deep-learning security intelligence copilot. My matrix is loaded with enterprise security modules, secure application engineering standards, and defensive logic structures.\n\n*Threat modeling, secure parameterization checks, sandbox evaluation, and diagnostic scripting layers are fully initialized.* How may I protect and elevate your code infrastructure today?",
        timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
      },
    ]);
    setErrorMsg(null);
    setInputText("");
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
      abortControllerRef.current = null;
    }
    setIsLoading(false);
    setRetryCount(0);
  };

  const handleClearChat = () => {
    setMessages([]);
    setErrorMsg(null);
    setInputText("");
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
      abortControllerRef.current = null;
    }
    setIsLoading(false);
    setRetryCount(0);
  };

  const handleRegenerateResponse = async () => {
    if (isLoading) return;

    let lastUserIdx = -1;
    for (let i = messages.length - 1; i >= 0; i--) {
      if (messages[i].role === "user") {
        lastUserIdx = i;
        break;
      }
    }

    if (lastUserIdx === -1) return;

    const cutHistory = messages.slice(0, lastUserIdx + 1);
    setMessages(cutHistory);

    const conversationHistory = cutHistory.map((msg) => ({
      role: msg.role,
      text: msg.text,
    }));

    await executeChatRequest(conversationHistory);
  };

  const handleRegenerateFromMessage = async (msgId: string) => {
    if (isLoading) return;

    const idx = messages.findIndex((m) => m.id === msgId);
    if (idx === -1) return;

    let lastUserIdx = -1;
    for (let i = idx - 1; i >= 0; i--) {
      if (messages[i].role === "user") {
        lastUserIdx = i;
        break;
      }
    }

    if (lastUserIdx === -1) return;

    const cutHistory = messages.slice(0, lastUserIdx + 1);
    setMessages(cutHistory);

    const conversationHistory = cutHistory.map((msg) => ({
      role: msg.role,
      text: msg.text,
    }));

    await executeChatRequest(conversationHistory);
  };

  return (
    <div 
      className="relative flex flex-col min-h-[920px] bg-[#070B12] rounded-3xl border border-cyan-500/15 shadow-2xl overflow-hidden font-sans select-none p-4 sm:p-8 md:p-12" 
      id="chat-assistant-stage-container"
    >
      <style dangerouslySetInnerHTML={{ __html: PREMIUM_CYBER_STYLE_INJECTION }} />

      {/* Full-width dynamic background canvas */}
      <canvas ref={canvasRef} className="absolute inset-0 w-full h-full pointer-events-none z-0" />

      {/* Decorative Corner HUD Coordinates */}
      <div className="absolute top-4 left-4 font-mono text-[9px] text-gray-600 select-none z-10 hidden md:block">
        GRID_COORD_X: [45.1228] // NODE_ONLINE
      </div>
      <div className="absolute top-4 right-4 font-mono text-[9px] text-gray-600 select-none z-10 hidden md:block">
        SYSTEM_AUTH: SECURITY_OPERATOR_LEVEL_STRICT
      </div>

      {/* Centered, Majestic, Highly Spacious HERO SECTION */}
      <div 
        className="relative z-10 flex flex-col items-center justify-center text-center mt-6 mb-12 select-none"
        id="cyber-wolf-hero-header"
      >
        {/* Giant ORIGINAL Premium Cyber Wolf Emblem with Layered Hologram Animations */}
        <div className="relative w-48 h-48 sm:w-52 sm:h-52 md:w-56 md:h-56 flex items-center justify-center flex-shrink-0">
          
          {/* Outer rotating dashed cyan ring */}
          <div 
            className="absolute inset-0 rounded-full border border-dashed border-[#00E5FF]/45 pointer-events-none"
            style={{
              animation: "ring-rotate-clockwise 25s linear infinite",
              boxShadow: "0 0 25px rgba(0, 229, 255, 0.12) inset, 0 0 25px rgba(0, 229, 255, 0.12)"
            }}
          />
          
          {/* Inner counter-rotating emerald ring */}
          <div 
            className="absolute inset-4 rounded-full border border-dashed border-[#00FF99]/30 pointer-events-none"
            style={{
              animation: "ring-rotate-counter 18s linear infinite"
            }}
          />

          {/* Third concentric thin neon ring */}
          <div 
            className="absolute inset-8 rounded-full border border-dotted border-[#00B8FF]/20 pointer-events-none"
            style={{
              animation: "ring-rotate-clockwise 40s linear infinite"
            }}
          />

          {/* Layered concentric holographic pulse waves radiating outward */}
          <div 
            className="absolute w-44 h-44 rounded-full border border-cyan-500/30 pointer-events-none"
            style={{
              animation: "premium-pulse-hologram 5s cubic-bezier(0.16, 1, 0.3, 1) infinite"
            }}
          />
          <div 
            className="absolute w-44 h-44 rounded-full border border-emerald-500/20 pointer-events-none"
            style={{
              animation: "premium-pulse-hologram 5s cubic-bezier(0.16, 1, 0.3, 1) infinite",
              animationDelay: "2.5s"
            }}
          />

          {/* Floating Cyber Particles drifting up around the wolf logo */}
          <div className="absolute inset-0 pointer-events-none overflow-hidden rounded-full">
            <span className="absolute bottom-2 left-1/4 w-1.5 h-1.5 rounded-full bg-cyan-400" style={{ animation: "float-particle 4s infinite linear", "--drift-x": "20px" } as any} />
            <span className="absolute bottom-4 right-1/3 w-1 h-1 rounded-full bg-emerald-400" style={{ animation: "float-particle 5s infinite linear", "--drift-x": "-15px", animationDelay: "1.5s" } as any} />
            <span className="absolute bottom-1 right-1/4 w-1.5 h-1.5 rounded-full bg-[#00E5FF]" style={{ animation: "float-particle 3.5s infinite linear", "--drift-x": "10px", animationDelay: "0.7s" } as any} />
          </div>

          {/* Majestic Cyber Wolf Logo centered, with slow breath glow pulse */}
          <div 
            className="relative z-10 w-36 h-36 sm:w-40 sm:h-40 md:w-44 md:h-44 flex items-center justify-center cursor-pointer"
            style={{
              animation: "cyber-breathing 6s ease-in-out infinite"
            }}
          >
            <svg viewBox="0 0 120 120" className="w-full h-full drop-shadow-[0_0_20px_rgba(0,229,255,0.25)]">
              <defs>
                <filter id="hero-cyan-glow" x="-20%" y="-20%" width="140%" height="140%">
                  <feGaussianBlur stdDeviation="3.0" result="blur" />
                  <feComposite in="SourceGraphic" in2="blur" operator="over" />
                </filter>
                <filter id="hero-emerald-glow" x="-20%" y="-20%" width="140%" height="140%">
                  <feGaussianBlur stdDeviation="2.0" result="blur" />
                  <feComposite in="SourceGraphic" in2="blur" operator="over" />
                </filter>
                <linearGradient id="wolf-shield-gradient" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#0B1528" stopOpacity="0.95" />
                  <stop offset="50%" stopColor="#050B12" stopOpacity="0.9" />
                  <stop offset="100%" stopColor="#020408" stopOpacity="0.98" />
                </linearGradient>
                <linearGradient id="cyber-metallic-grad" x1="0%" y1="0%" x2="0%" y2="100%">
                  <stop offset="0%" stopColor="#00E5FF" />
                  <stop offset="100%" stopColor="#005B8F" />
                </linearGradient>
              </defs>

              {/* Primary 3D Holographic Shield Base */}
              <path 
                d="M 60 4 L 112 20 L 112 76 Q 60 116 8 76 L 8 20 Z" 
                fill="url(#wolf-shield-gradient)" 
                stroke="url(#cyber-metallic-grad)" 
                strokeWidth="2.8" 
                filter="url(#hero-cyan-glow)"
              />
              <path 
                d="M 60 9 L 104 24 L 104 71 Q 60 106 16 71 L 16 24 Z" 
                fill="none" 
                stroke="rgba(0, 255, 153, 0.28)" 
                strokeWidth="1.2" 
              />

              {/* Holographic Grid Lines */}
              <line x1="22" y1="35" x2="98" y2="35" stroke="rgba(0, 229, 255, 0.16)" strokeWidth="0.6" strokeDasharray="4 4" />
              <line x1="16" y1="55" x2="104" y2="55" stroke="rgba(0, 229, 255, 0.16)" strokeWidth="0.6" strokeDasharray="4 4" />
              <line x1="16" y1="75" x2="104" y2="75" stroke="rgba(0, 229, 255, 0.16)" strokeWidth="0.6" strokeDasharray="4 4" />
              <line x1="60" y1="9" x2="60" y2="108" stroke="rgba(0, 229, 255, 0.16)" strokeWidth="0.6" strokeDasharray="4 4" />

              {/* Cyber Wolf Sharp Geometric Ears */}
              <polygon points="42,38 16,10 46,25" fill="#02050B" stroke="#00E5FF" strokeWidth="1.4" />
              <polygon points="78,38 104,10 74,25" fill="#02050B" stroke="#00E5FF" strokeWidth="1.4" />
              <polygon points="39,33 24,18 40,26" fill="#00FF99" fillOpacity="0.3" />
              <polygon points="81,33 96,18 80,26" fill="#00FF99" fillOpacity="0.3" />

              {/* Head Crest */}
              <polygon points="60,26 44,45 76,45" fill="#050C17" stroke="#00E5FF" strokeWidth="1" />

              {/* Geometric Cheeks */}
              <polygon points="44,45 24,58 42,66 60,51" fill="#010204" stroke="#00E5FF" strokeWidth="1" />
              <polygon points="76,45 96,58 78,66 60,51" fill="#010204" stroke="#00E5FF" strokeWidth="1" />
              <polygon points="24,58 12,66 28,70" fill="#020408" stroke="#00FF99" strokeWidth="1" />
              <polygon points="96,58 108,66 92,70" fill="#020408" stroke="#00FF99" strokeWidth="1" />

              {/* Center Forehead Core */}
              <polygon points="60,26 50,45 60,51 70,45" fill="#0A182D" stroke="#00E5FF" strokeWidth="1" />

              {/* Sharp Cyber Snout */}
              <polygon points="60,51 44,66 60,96 76,66" fill="#03070E" stroke="#00E5FF" strokeWidth="1.4" />
              <line x1="49" y1="72" x2="71" y2="72" stroke="#00FF99" strokeWidth="1" />
              <line x1="53" y1="80" x2="67" y2="80" stroke="#00E5FF" strokeWidth="1" />

              {/* Glowing Laser Eyes */}
              <polygon points="43,46 51,48 47,51" fill="#00E5FF" filter="url(#hero-cyan-glow)" />
              <polygon points="77,46 69,48 73,51" fill="#00E5FF" filter="url(#hero-cyan-glow)" />
              <circle cx="47" cy="48" r="1.2" fill="#FFFFFF" />
              <circle cx="73" cy="48" r="1.2" fill="#FFFFFF" />

              {/* Glowing Emerald Nose */}
              <polygon points="54,87 60,96 66,87" fill="#00FF99" filter="url(#hero-emerald-glow)" />

              {/* Symmetrical Geometric Jaw Lines */}
              <polygon points="44,66 36,78 46,86 60,96" fill="#010103" stroke="#00FF99" strokeWidth="1" />
              <polygon points="76,66 84,78 74,86 60,96" fill="#010103" stroke="#00FF99" strokeWidth="1" />
            </svg>
          </div>
        </div>

        {/* Dynamic Title and Developer HUD Info */}
        <div className="mt-6 flex flex-col items-center">
          <h1 
            className="text-3xl sm:text-4xl md:text-5xl font-black font-mono tracking-[0.24em] text-white uppercase"
            style={{ animation: "title-shimmer 4s ease-in-out infinite" }}
          >
            BLACK_WOLF <span className="text-[#00E5FF]">AI</span>
          </h1>
          
          <div className="mt-2 text-xs sm:text-sm font-mono tracking-[0.3em] uppercase text-cyan-400 font-bold flex items-center gap-2">
            <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-ping" />
            <span>Enterprise Security Copilot</span>
          </div>

          {/* Premium Developer Frame */}
          <div className="mt-6 flex flex-col items-center gap-1.5 border border-cyan-500/15 bg-[#09111F]/55 backdrop-blur-md px-6 py-3 rounded-2xl max-w-md shadow-lg">
            <div className="text-[10px] font-mono tracking-widest text-gray-500 font-bold uppercase">
              COGNITIVE LABS DEVELOPER
            </div>
            <div className="text-sm font-black font-mono tracking-[0.2em] text-white uppercase">
              P SOWNDHAR
            </div>
            <div className="flex items-center gap-2 text-[10px] font-mono text-[#00FF99] font-bold uppercase tracking-wider">
              <span className="inline-block w-2 h-2 rounded-full bg-[#00FF99]" style={{ animation: "state-active-pulse 1.8s infinite" }} />
              <span>Professional Hacker</span>
            </div>
          </div>
        </div>

        {/* Matrix Operational Level Controller */}
        <div className="mt-8 flex flex-col items-center gap-3">
          <span className="text-[10px] font-mono font-black tracking-widest text-gray-500 uppercase">
            CHOOSE OPERATIONAL PARAMETER MATRIX LEVEL
          </span>
          <div className="flex items-center gap-2 bg-[#040810]/95 border border-cyan-500/20 p-1 rounded-2xl shadow-xl z-10">
            {(["beginner", "intermediate", "advanced"] as UserSkillLevel[]).map((level) => (
              <button
                key={level}
                id={`btn-level-large-${level}`}
                onClick={() => setUserLevel(level)}
                className={`text-[10px] sm:text-xs font-mono font-bold px-5 py-2.5 rounded-xl tracking-wider transition-all uppercase cursor-pointer ${
                  userLevel === level
                    ? "bg-cyan-500/15 text-[#00E5FF] border border-cyan-500/40 shadow-[0_0_15px_rgba(0,229,255,0.2)]"
                    : "text-gray-500 hover:text-white hover:bg-slate-900/50"
                }`}
              >
                {level} Matrix
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Spacious Premium Glassmorphism Chat Container */}
      <div 
        className="relative z-10 max-w-5xl w-full mx-auto flex flex-col h-[650px] sm:h-[720px] rounded-3xl border border-cyan-500/20 bg-[#070B12]/75 backdrop-blur-2xl shadow-[0_30px_70px_rgba(0,0,0,0.9)] overflow-hidden"
        id="cyber-chat-panel"
      >
        {/* Terminal Header Decorator */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-cyan-500/15 bg-[#080E1C]/90 select-none">
          <div className="flex items-center gap-3">
            <span className="flex space-x-1.5">
              <span className="w-3 h-3 rounded-full bg-red-500/50 border border-red-500/20" />
              <span className="w-3 h-3 rounded-full bg-yellow-500/50 border border-yellow-500/20" />
              <span className="w-3 h-3 rounded-full bg-green-500/50 border border-green-500/20" />
            </span>
            <div className="h-4 w-[1px] bg-cyan-500/20 mx-1" />
            <div className="flex items-center gap-2 text-xs font-mono text-gray-400 font-bold tracking-widest uppercase">
              <Terminal className="h-3.5 w-3.5 text-[#00E5FF]" />
              <span>TERMINAL_CONEX: COGNITIVE_THREAD_1</span>
            </div>
          </div>
          <div className="flex items-center gap-4 text-[10px] font-mono text-gray-500 font-bold uppercase tracking-widest hidden sm:flex">
            <span>MODEL: {userLevel.toUpperCase()}_WEIGHTS</span>
            <span className="w-2 h-2 rounded-full bg-emerald-500" style={{ animation: "state-active-pulse 1.5s infinite" }} />
          </div>
        </div>

        {/* Message Feeds Area */}
        <div 
          className="flex-1 overflow-y-auto p-6 sm:p-8 space-y-6 relative cyber-scroller"
          id="chat-scrolling-container"
        >
          <AnimatePresence initial={false}>
            {messages.map((message) => {
              const isBot = message.role === "model";
              return (
                <motion.div
                  key={message.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
                  className={`flex gap-5 ${isBot ? "justify-start" : "justify-end"}`}
                >
                  {/* Bot Avatar Icon */}
                  {isBot && (
                    <div className="h-10 w-10 rounded-xl glass-cyber-panel text-[#00E5FF] flex items-center justify-center flex-shrink-0 self-start shadow-md border border-cyan-500/25">
                      <Bot className="h-5 w-5 animate-pulse" />
                    </div>
                  )}
                  
                  <div className={`flex flex-col max-w-[85%] sm:max-w-[78%] ${isBot ? "items-start" : "items-end"}`}>
                    <div
                      className={`px-6 py-5 rounded-3xl text-[13px] leading-relaxed relative group/msg transition-all duration-300 ${
                        isBot
                          ? "glass-card-assistant-premium text-slate-100 hover:border-cyan-500/20"
                          : "glass-card-user-premium text-[#E0FDF4] hover:border-[#00FF99]/35 font-mono"
                      }`}
                    >
                      {isBot ? (
                        <div className="markdown-body pr-4">
                          <Markdown
                            components={{
                              code: CodeBlock,
                              table: TableComponent,
                              thead: TableHeaderComponent,
                              tbody: TableBodyComponent,
                              tr: TableRowComponent,
                              td: TableCellComponent,
                              h1: Heading1Component,
                              h2: Heading2Component,
                              h3: Heading3Component,
                              ul: BulletListComponent,
                              ol: NumberedListComponent,
                              a: LinkComponent
                            }}
                          >
                            {message.text}
                          </Markdown>

                          {/* Hover Action Controls */}
                          {message.id !== "welcome" && message.id !== "welcome-reset" && message.id !== "welcome-new" && (
                            <div className="absolute right-4 bottom-4 opacity-0 group-hover/msg:opacity-100 transition-opacity flex gap-1.5 bg-[#0A101C] p-2 rounded-xl border border-cyan-500/25 select-none shadow-lg">
                              <button
                                onClick={() => handleRegenerateFromMessage(message.id)}
                                disabled={isLoading}
                                title="Regenerate core conversation weights from here"
                                className="p-1.5 hover:bg-slate-900 text-gray-400 hover:text-[#00FF99] rounded-lg transition-colors cursor-pointer disabled:opacity-30"
                              >
                                <RefreshCw className="h-4 w-4" />
                              </button>
                            </div>
                          )}
                        </div>
                      ) : (
                        <p className="whitespace-pre-wrap selection:bg-[#00FF99]/20 selection:text-[#00FF99]">{message.text}</p>
                      )}
                    </div>
                    <span className="text-[9px] font-mono text-gray-500 mt-2 px-3 font-semibold tracking-wider flex items-center gap-1.5 select-none">
                      {isBot ? <span className="w-1.5 h-1.5 rounded-full bg-cyan-400" /> : <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />}
                      {message.timestamp}
                    </span>
                  </div>

                  {/* User Avatar Icon */}
                  {!isBot && (
                    <div className="h-10 w-10 rounded-xl glass-cyber-panel text-[#00FF99] flex items-center justify-center flex-shrink-0 self-start shadow-md border border-[#00FF99]/25">
                      <User className="h-5 w-5" />
                    </div>
                  )}
                </motion.div>
              );
            })}
          </AnimatePresence>

          {/* Thinking States / Loader */}
          {isLoading && (
            <div className="flex gap-5 justify-start">
              <div className="h-10 w-10 rounded-xl glass-cyber-panel text-[#00E5FF] flex items-center justify-center flex-shrink-0 self-start animate-spin" style={{ animationDuration: "3.5s" }}>
                <Bot className="h-5 w-5" />
              </div>
              <div className="flex flex-col items-start max-w-[85%]">
                {retryCount > 0 ? (
                  <div className="bg-[#1A1105]/80 text-[#FFA000] border border-[#FFA000]/30 px-6 py-5 rounded-3xl text-xs flex flex-col gap-3.5 shadow-xl backdrop-blur-md max-w-md animate-pulse">
                    <div className="flex items-center gap-2.5">
                      <AlertTriangle className="h-4 w-4 text-[#FFA000]" />
                      <span className="font-mono font-black uppercase tracking-wider text-[10px]">
                        TRANSACTION_RETRY_MODE
                      </span>
                    </div>
                    <div className="space-y-1 font-mono text-[11px] leading-relaxed">
                      <p className="font-bold text-white">⚠ TRANSACTION COGNITIVE TIMEOUT</p>
                      <p className="text-gray-400">Revising weights, establishing parallel pipeline stream...</p>
                      <p className="text-[#00FF99] font-black">RETRYING CONNECTION ({retryCount} / 5)...</p>
                    </div>
                    <div className="w-full bg-slate-900 rounded-full h-1 overflow-hidden mt-1">
                      <div 
                        className="bg-[#FFA000] h-1 transition-all duration-500"
                        style={{ width: `${(retryCount / 5) * 100}%` }}
                      />
                    </div>
                  </div>
                ) : (
                  <div className="bg-[#050912]/90 text-[#00E5FF] border border-cyan-500/20 px-5 py-3.5 rounded-2xl text-xs flex items-center gap-3.5 backdrop-blur-md shadow-lg">
                    <span className="flex space-x-1.5">
                      <span className="h-2 w-2 bg-[#00E5FF] rounded-full animate-bounce" style={{ animationDelay: "0ms" }} />
                      <span className="h-2 w-2 bg-[#00FF99] rounded-full animate-bounce" style={{ animationDelay: "150ms" }} />
                      <span className="h-2 w-2 bg-[#00E5FF] rounded-full animate-bounce" style={{ animationDelay: "300ms" }} />
                    </span>
                    <span className="text-[10px] font-mono tracking-widest uppercase font-black text-gray-400">ALIGNING WEIGHT COGNITIVE MODEL...</span>
                  </div>
                )}
              </div>
            </div>
          )}

          {errorMsg && (
            <div className="flex gap-5 justify-center p-6 bg-red-950/25 border border-red-500/25 rounded-3xl max-w-2xl mx-auto backdrop-blur-md">
              <AlertTriangle className="h-5 w-5 text-red-400 flex-shrink-0 mt-0.5" />
              <div className="flex flex-col gap-2">
                <h4 className="text-xs font-black font-mono tracking-wider text-red-300 uppercase">BLACK_WOLF COGNITIVE CRITICAL FAILURE</h4>
                <p className="text-xs text-red-200/90 leading-relaxed font-mono">{errorMsg}</p>
                {isConfigError && (
                  <div className="mt-3 text-xs bg-slate-950/90 p-4 rounded-2xl border border-red-500/15 text-slate-300 leading-relaxed font-sans">
                    <strong className="text-white font-mono text-[11px] tracking-wider block mb-1.5">MANUAL INTERVENTION PROCEDURES:</strong>
                    <ol className="list-decimal pl-4.5 space-y-1.5 text-gray-400 font-mono text-[10px]">
                      <li>Access the top header / settings navigation tab in AI Studio.</li>
                      <li>Locate <strong>Secrets</strong> or <strong>Environment Variables</strong> configuration panel.</li>
                      <li>Verify key <strong>GEMINI_API_KEY</strong> exists with valid API Credentials.</li>
                    </ol>
                  </div>
                )}
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Suggested Queries Deck */}
        <div className="px-6 sm:px-8 py-4 bg-[#080E1C]/85 backdrop-blur-md border-t border-cyan-500/10 select-none" id="hero-prompt-suggestions">
          <p className="text-[10px] font-mono text-gray-500 uppercase tracking-widest mb-3 flex items-center gap-2 font-bold">
            <Terminal className="h-4 w-4 text-[#00E5FF]" /> RECOMMENDED MODEL CHECKS ({userLevel.toUpperCase()} LEVEL):
          </p>
          <div className="flex flex-wrap gap-2">
            {STARTER_PROMPTS[userLevel].map((prompt, index) => (
              <button
                key={index}
                id={`starter-prompt-${index}`}
                onClick={() => handleSendMessage(prompt.text)}
                disabled={isLoading}
                className="text-[11px] bg-[#0A1424]/40 hover:bg-[#00E5FF]/8 text-gray-400 hover:text-[#00E5FF] border border-cyan-500/10 hover:border-cyan-500/35 px-4 py-2.5 rounded-2xl transition-all flex items-center gap-2.5 cursor-pointer disabled:opacity-40 font-mono tracking-wide"
              >
                <span>{prompt.label}</span>
                <ArrowRight className="h-3 w-3 text-[#00FF99] opacity-75" />
              </button>
            ))}
          </div>
        </div>

        {/* Glassmorphic Rounded Input Base (Fixed at bottom of chat card) */}
        <div className="p-6 sm:p-8 bg-[#080E1C]/95 backdrop-blur-md border-t border-cyan-500/20 flex flex-col gap-5 relative z-10" id="input-container">
          <div className="flex flex-wrap justify-between items-center gap-3 w-full select-none">
            {/* Command Utilities */}
            <div className="flex flex-wrap gap-2">
              <button
                onClick={handleNewChat}
                title="Initialize Fresh Operating Session"
                id="btn-new-chat"
                className="px-5 py-2.5 rounded-2xl bg-cyan-950/20 border border-cyan-500/20 text-gray-400 hover:text-[#00E5FF] hover:border-cyan-500/45 transition-all flex items-center gap-2 text-xs font-mono font-bold cursor-pointer"
              >
                <Sparkles className="h-4 w-4 text-[#00E5FF]" />
                <span>INIT_NEW_SESSION</span>
              </button>

              <button
                onClick={handleClearChat}
                title="Purge Operational Context"
                id="btn-clear-chat"
                className="px-5 py-2.5 rounded-2xl bg-[#1A0B0E]/20 border border-red-500/15 text-gray-500 hover:text-red-400 hover:border-red-500/30 transition-all flex items-center gap-2 text-xs font-mono font-bold cursor-pointer"
              >
                <RotateCcw className="h-4 w-4 text-red-500/60" />
                <span>PURGE_BUFFER</span>
              </button>

              <button
                onClick={handleRegenerateResponse}
                disabled={isLoading || !messages.some(m => m.role === "user")}
                title="Regenerate last response"
                id="btn-regenerate-chat"
                className="px-5 py-2.5 rounded-2xl bg-cyan-950/20 border border-cyan-500/15 text-gray-500 hover:text-[#00FF99] hover:border-[#00FF99]/30 disabled:opacity-30 transition-all flex items-center gap-2 text-xs font-mono font-bold cursor-pointer"
              >
                <RefreshCw className="h-4 w-4 text-[#00FF99]/60" />
                <span>RECALCULATE_LAST</span>
              </button>
            </div>

            <div className="text-[10px] font-mono text-gray-500 uppercase tracking-widest hidden sm:block font-bold">
              SYS_TUNNEL: INGRESS_PORT_3000 // STRICT_AES_GCM
            </div>
          </div>

          {/* Form Command Line */}
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSendMessage(inputText);
            }}
            className="flex gap-3 w-full"
          >
            <input
              type="text"
              value={inputText}
              id="chat-input-text"
              onChange={(e) => setInputText(e.target.value)}
              disabled={isLoading}
              placeholder={`Instruct BLACK_WOLF AI security copilot... (${userLevel} operational model)`}
              className="flex-1 glass-input-box text-white rounded-2xl px-6 py-4 text-sm focus:outline-none placeholder-gray-600 disabled:opacity-50 font-mono selection:bg-cyan-500/20 selection:text-cyan-300"
            />
            <button
              type="submit"
              id="btn-send-chat"
              disabled={!inputText.trim() || isLoading}
              className="bg-cyan-500/10 border border-cyan-500/35 px-6 py-4 rounded-2xl font-mono text-xs font-bold text-[#00E5FF] hover:text-white hover:bg-[#00E5FF]/20 hover:border-[#00E5FF] hover:shadow-[0_0_20px_rgba(0,229,255,0.3)] transition-all flex items-center gap-3 disabled:opacity-40 disabled:hover:shadow-none disabled:hover:bg-cyan-500/10 disabled:hover:text-[#00E5FF] disabled:hover:border-cyan-500/35 disabled:cursor-not-allowed cursor-pointer select-none"
            >
              <span className="hidden sm:inline tracking-wider">EXECUTE_COMMAND</span>
              <Send className="h-4 w-4 animate-pulse" />
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
